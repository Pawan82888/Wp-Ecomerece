<?php
function pw_wpsc_cloudbanking_settings_form() {
	global $wpdb;
	
	$auth_key    = get_option( 'wpsc_auth_key' );	
	$api_version = get_option( 'wpsc_api_version' );	
	$customer_id = get_option( 'wpsc_customer_id' );	
	
  
	$output = "<tr>\n\r
				<td>Auth Key</td>
				<td><input type='text' size='30' value='" . $auth_key . "' name='wpsc_auth_key' /></td>
			</tr>
			<tr>
				<td>Api Version</td>
				<td><input type='text' size='30' value='" . $api_version . "' name='wpsc_api_version' /></td>
			</tr>
			<tr>
				<td>Customer ID</td>
				<td><input type='text' size='30' value='" . $customer_id . "' name='wpsc_customer_id' /></td>
		    </tr>
			<tr>	
			</tr>\n\r";
			
    if( $auth_key == '' || $api_version == '' )
    {
        $output .='
        <tr>
        	<td colspan="2">
        	<strong style="color:red;"> '.__( 'Auth key is Required/Api is Required', 'wpsc' ). ' </strong>
        	</td>
        </tr>
        ';		

    } 	
	return $output;
}

function pw_wpsc_save_cloudbanking_settings() {
	
	$options = array(
		'wpsc_auth_key',
		'wpsc_api_version',
		'wpsc_customer_id'
	);
	
	foreach ( $options as $option ) {
		if ( ! empty( $_POST[ $option ] ) ) {
			update_option( $option, sanitize_text_field( $_POST[ $option ] ) );
		}
	}
	
	return true;
}
