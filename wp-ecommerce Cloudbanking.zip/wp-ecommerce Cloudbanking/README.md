=== WP eCommerce Cloudbanking ===
Tags: gateway, ecommerce, wp ecommerce, WP eCommerce, wp e-commerce, WP e-commerce,Cloudbanking,Cloudbanking pay, gateway, integration, payment, payment gateway, WP eCommerce gateway, WP eCommerce Cloudbanking, WP e-Commerce Cloudbanking
Requires at least: 4.0.0
Tested up to: 4.8.2
License: GPLv2

Cloudbanking Payment Gateway eCommerce.


== Installation ==
1. Upload the 'wp-e-commerce-cloudbanking' folder to /wp-content/plugins/ on your server.
2. Log in to Wordpress administration, click on the 'Plugins' tab.
3. Find "Cloudbanking Payment Gateway for WP eCommerce" in the plugin overview and activate it.
4. Go to Settings -> Store -> Payments.
5. Locate the Cloudbanking Payment Gateway for WP eCommerce and click the "Settings" button.
5. Fill in your account settings and save the settings.
6. You are good to go.
