<?php
/*
Plugin Name: Cloudbanking Payment Gateway for WP eCommerce
Plugin URI: 
Description: Integrate the Cloudbanking Payment Gateway into WP eCommerce.
Version: 2.1
Author: Pawan Kumar
Author URI: 
*/

defined( 'WPINC' ) || die;

class WPSC_Cloudbanking {

	private static $instance;

	private function __construct() {}

	public static function get_instance() {

		if  ( ! isset( self::$instance ) && ! ( self::$instance instanceof WPSC_Cloudbanking ) ) {
			self::$instance = new WPSC_Cloudbanking;

			self::define_constants();
			self::includes();

			self::add_actions();
			self::add_filters();
		}

		return self::$instance;
	}

	public static function define_constants() {

		define( 'PW_WPSC_PLUGIN_DIR', dirname( __FILE__ ) );
	}

	public static function includes() {
	
		include_once PW_WPSC_PLUGIN_DIR . '/includes/checkout-fields.php';
		include_once PW_WPSC_PLUGIN_DIR . '/includes/gateway-settings.php';
	}

	public static function add_actions() {
		add_action( 'wpsc_init', array( self::$instance, 'init' ), 2 );

		/* Defined in checkout-fields.php */
		add_action( 'wpsc_init', 'pw_wpsc_cloudbanking_checkout_fields' );

	
		
	}

	public static function add_filters() {
		add_filter( 'wpsc_merchants_modules', array( self::$instance, 'register_gateway' ), 50 );
	}

	public function init() {
		include_once PW_WPSC_PLUGIN_DIR . '/pw_wpsc_cloudbanking.php';
	}

	public function register_gateway( $gateways ) {

		$num = max( array_keys( $gateways ) ) + 1;

		$gateways[ $num ] = array(
			'name'                   => 'Cloudbanking',
			'api_version'            => 2.0,
			'has_recurring_billing'  => true,
			'display_name'           => __( 'Cloudbanking' ),
			'image'                  => WPSC_URL . '/images/cc.gif',
			'wp_admin_cannot_cancel' => false,
			'requirements' => array(
				'php_version' => 5.0
			),
			'class_name'      => 'pw_wpsc_cloudbanking',
			'form'            => 'pw_wpsc_cloudbanking_settings_form',
			'submit_function' => 'pw_wpsc_save_cloudbanking_settings',
			'internalname'    => 'wpsc_cloudbanking'
		);

		return $gateways;
	}

}

add_action( 'wpsc_pre_init', 'WPSC_Cloudbanking::get_instance' );
