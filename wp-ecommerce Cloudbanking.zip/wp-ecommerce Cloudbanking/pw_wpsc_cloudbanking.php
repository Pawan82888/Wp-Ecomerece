<?php

require_once(__DIR__ . '/vendor/autoload.php');
use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;

class pw_wpsc_cloudbanking extends wpsc_merchant {

	public $name = 'Cloudbanking';

	/**
	* construct value array method, converts the data gathered by the base class code to something acceptable to the gateway
	* @access public
	*/
	function construct_value_array() {
		$this->collected_gateway_data = $this->_construct_value_array();
	}
	
	function _construct_value_array( $aggregate = false ) {
		global $wpdb;

		$cloudbanking_vars = array();
		
		
		$currency_code  = $wpdb->get_var( "SELECT `code` FROM `" . WPSC_TABLE_CURRENCY_LIST . "` WHERE `id`='" . get_option( 'currency_type' ) . "' LIMIT 1" );

		// Store settings to be sent to cloudbanking
		$cloudbanking_vars += array(
			'currency_code' => $currency_code,
			'email'         => $this->cart_data['email_address'],
			'first_name'    => $this->cart_data['billing_address']['first_name'],
			'last_name'     => $this->cart_data['billing_address']['last_name'],
			'address1'      => $this->cart_data['billing_address']['address'],
			'city'          => $this->cart_data['billing_address']['city'],
			'country'       => $this->cart_data['billing_address']['country'],
			'zip'           => $this->cart_data['billing_address']['post_code'],
			'state'         => $this->cart_data['billing_address']['state'],
			'cc_number'     => sanitize_text_field($_POST['card_number']),
			'cc_exp_month'  => sanitize_text_field($_POST['expiry']['month']),
			'cc_exp_year'   => sanitize_text_field($_POST['expiry']['year']),
			'cc_card_cvc'   => sanitize_text_field($_POST['card_code'])
		);

		// Two cases:
		// - We're dealing with a subscription
		// - We're dealing with a normal cart
		if ($this->cart_data['is_subscription']) {
			$cloudbanking_vars += array(
				'is_recurring'=> true,
			);
			
			$reprocessed_cart_data['subscription'] = array(
				'product_name' => false,
				'product_id' => false,
				'price' => 0,
				'length' => 1,
				'unit' => 'D'
			);

			foreach ($this->cart_items as $cart_row) {
				if ($cart_row['is_recurring']) {
					$reprocessed_cart_data['subscription']['product_name'] = $cart_row['name'];
					$reprocessed_cart_data['subscription']['product_id'] = $cart_row['product_id'];
					$reprocessed_cart_data['subscription']['price'] = $cart_row['price'];
					$reprocessed_cart_data['subscription']['length'] = $cart_row['recurring_data']['rebill_interval']['length'];
					$reprocessed_cart_data['subscription']['unit'] = strtoupper($cart_row['recurring_data']['rebill_interval']['unit']);
				} else {
					$item_cost = ($cart_row['price'] + $cart_row['shipping'] + $cart_row['tax']) * $cart_row['quantity'];

					if ($item_cost > 0) {
						$reprocessed_cart_data['shopping_cart']['price'] += $item_cost;
						$reprocessed_cart_data['shopping_cart']['is_used'] = true;
					}
				}
			} // end foreach cart item
			
			$cloudbanking_vars += array(
				'subscription_data' => $reprocessed_cart_data
			);			
			
		} else {
			$cloudbanking_vars += array(
				'is_recurring'=> false,
			);
	
		}
		return apply_filters( 'wpsc_cloudbanking_post_data', $cloudbanking_vars );
	}
	
	/**
	* submit method, sends the received data to the payment gateway
	* @access public
	*/
	function submit() {
		
		global $purchase_log, $user_ID;
	
		// get all subscription level info for this plan
		$price = $price * 100;
		
		// cloudbanking::setApiKey($secret_key);			
		
		$paid = false;
			
		if ( $this->name=='Cloudbanking' ) {

			$data=$this->collected_gateway_data;
			$card = $this->createcard($data);
			$gateway = $this->gateway_instance();
			$gateway->setParameter('card', $card);
			$createCardRequest = $gateway->createCard();
			$cardCreateResponse = $createCardRequest->send();
			// process a subscription sign up
			if ($cardCreateResponse->isSuccessful()) {
				// Process transaction
				$cardToken = $cardCreateResponse->getToken();
				$total_amount = $this->format_price($this->cart_data['total_price']);
				$transaction = $gateway->purchase(array(	  
						'cardReference' 		=> $cardToken,
						'amount'     			=> $total_amount,
						'transactionId'			=> $this->purchase_id,
				));

				$response = $transaction->send();
				if ($response->isSuccessful()) {
					// echo "Purchase transaction was successful!\n";
					$banktransactionid = $response->getTransactionReference();
					$cardtoken=$response->getCardReference();
					$paid = true;
				}
				else{
					$body = $response->getMessage(); 
					$message .= "<h3>".__( 'Please Check the Payment Results', 'wpsc_gold_cart' )."</h3>";
					$message .= __( 'Your transaction was not successful.', 'wpsc_gold_cart' ) . '<strong style="color:red">'.$body . "</strong><br /><br />";
					$errors = wpsc_get_customer_meta( 'checkout_misc_error_messages' );
					wpsc_update_customer_meta( 'checkout_misc_error_messages', $errors );
					header( 'Location: '.$checkout_page_url );
					exit();
				}
			}
			else{
				$body = $cardCreateResponse->getMessage(); 
				$message .= "<h3>".__( 'Please Check the Payment Results', 'wpsc_gold_cart' )."</h3>";
				$message .= __( 'Your transaction was not successful.', 'wpsc_gold_cart' ) . '<strong style="color:red">'.$body . "</strong><br /><br />";
				$errors = wpsc_get_customer_meta( 'checkout_misc_error_messages' );
				wpsc_update_customer_meta( 'checkout_misc_error_messages', $errors );
				header( 'Location: '.$checkout_page_url );
				exit();
			}	
		if ( $paid ) {
			$status = 3; // success
		} else {
			$status = 6; // failed
		}		
		
		$this->set_transaction_details( $cloudbanking_payment_id, $status );
		
		transaction_results( $this->cart_data['session_id'], false );		
		
		$redirect = add_query_arg('sessionid', $this->cart_data['session_id'], $this->cart_data['transaction_results_url']);
		
		wp_redirect( $redirect ); 
		exit;
	}
}
	
	function format_price( $amount ) {
		return $amount * 100;
	}

	public function createcard($data){
	
		$card = new CreditCard();
		
		// Card details
		$card->setNumber($data['cc_number']);
		$card->setExpiryYear($data['cc_exp_year']);
		$card->setExpiryMonth($data['cc_exp_month']);
		$card->setCvv(trim($data['cc_card_cvc']));
	
		// Billing details
		$card->setBillingFirstName($_POST['collected_data'][2]);
		$card->setBillingLastName($_POST['collected_data'][3]);
		$card->setBillingAddress1($_POST['collected_data'][4]);
		$card->setBillingAddress2($_POST['collected_data'][5]);
		$card->setBillingCity($_POST['collected_data'][4]);
		$card->setBillingCountry($_POST['collected_data'][7]);
		$card->setBillingState($_POST['collected_data'][5]);
		$card->setBillingPhone($_POST['collected_data'][18]);
		$card->setBillingPostcode($_POST['collected_data'][8]);
		$card->setBillingPhone($_POST['collected_data'][18]);
		// Shipping details
		$card->setShippingFirstName($_POST['collected_data'][11]);
		$card->setShippingLastName($_POST['collected_data'][12]);
		$card->setShippingAddress1($_POST['collected_data'][13]);
		$card->setShippingCity($_POST['collected_data'][14]);
		$card->setShippingState($_POST['collected_data'][15]);
		$card->setShippingPostcode($_POST['collected_data'][17]);
		return $card;
	}

	public function gateway_instance(){
		
		include_once( PW_WPSC_PLUGIN_DIR . '/cloudbanking.php' );		
		
		$gateway = Omnipay::create('CloudBanking');
		$gateway->setAuthkey( get_option( 'wpsc_auth_key' ) );
		$gateway->setApiVersion( get_option( 'wpsc_api_version' ) );
		$gateway->setCustomerReference( get_option( 'wpsc_customer_id' ) );
		
		return $gateway;
	}
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$gateway = $this->gateway_instance();
	}

	
}